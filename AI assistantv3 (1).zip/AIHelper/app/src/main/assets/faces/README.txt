नया चेहरा जोड़ना / बदलना:
1. इस फ़ोल्डर में कोई भी .json फ़ाइल बनाओ (जैसे mera.json)। रंग और speed बदलकर नया रूप मिल जाता है।
2. "type" = orb | robot | holo (ये तीन ड्रॉइंग-स्टाइल हैं, कोड face/ फ़ोल्डर में OrbFace.kt, RobotFace.kt, HoloFace.kt)।
3. बिल्कुल नई शक्ल चाहिए तो face/ में नई फ़ाइल बनाओ जो FaceRenderer implement करे, और FaceRenderer.forType() में एक लाइन जोड़ो।
ऐप में menu → "AI का चेहरा" में नया चेहरा अपने आप दिखेगा।
