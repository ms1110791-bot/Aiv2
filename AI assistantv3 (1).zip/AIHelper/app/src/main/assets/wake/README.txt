अपने नाम वाला wake word (Porcupine):
1. console.picovoice.ai पर खाता बनाओ -> AccessKey कॉपी करो (ऐप में menu -> नाम / Wake word में डालो)।
2. Porcupine -> अपना नाम (जैसे "Jarvis", "Friday") लिखो, भाषा चुनो, Platform = Android, Train करो।
3. जो .ppn फ़ाइल मिले उसे ऐप में "अपना .ppn चुनो" से चुन लो। (हिंदी जैसी दूसरी भाषा हो तो उस भाषा की .pv फ़ाइल भी चुनो।)
बिना .ppn के ऐप Porcupine के बने-बनाए नाम (JARVIS, COMPUTER, ALEXA आदि) चला लेता है।
