package com.myai.assistant.ui.sections

import android.app.Activity
import android.widget.LinearLayout
import com.myai.assistant.core.Prefs
import com.myai.assistant.providers.Keys
import com.myai.assistant.providers.ProviderConfig
import com.myai.assistant.theme.Theme
import com.myai.assistant.ui.UiKit

/** कई AI के API: जोड़ो, क्रम बदलो, हटाओ। ऊपर वाला पहले चलता है, फेल हो तो अगला। */
object AiSection {
    fun build(a: Activity, col: LinearLayout) {
        val ui = UiKit(a)
        val prefs = Prefs.of(a)
        val list = prefs.providers()

        col.addView(ui.hint("एक या ज़्यादा AI जोड़ो। कोई भी न जोड़ो तब भी ऐप ऑफलाइन फ़ोन-कमांड और ब्राउज़र सर्च से चलता है। हर बदलाव अपने-आप सेव होता है।"))

        val box = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        col.addView(box)

        fun save() = prefs.saveProviders(list)

        fun render() {
            box.removeAllViews()
            list.forEachIndexed { i, p ->
                val card = ui.card()
                card.addView(ui.text("${i + 1}. ${p.name}  (${if (p.type == "gemini") "Gemini" else "OpenAI-जैसा"})", 15f, Theme.accent, true))

                card.addView(ui.text("नाम (सिर्फ़ पहचान के लिए)", 12f, Theme.textDim).apply { setPadding(0, ui.dp(10), 0, ui.dp(4)) })
                card.addView(ui.edit(p.name, false) { p.name = it; save() })

                card.addView(ui.text("API key", 12f, Theme.textDim).apply { setPadding(0, ui.dp(10), 0, ui.dp(4)) })
                val status = ui.hint(if (p.key.isBlank()) "खाली" else "✓ सेव (${p.key.length} अक्षर)")
                val keyEdit = ui.edit(p.key, true) { v ->
                    p.key = Keys.clean(v, p.type)
                    status.text = if (p.key.isBlank()) "खाली" else "✓ सेव (${p.key.length} अक्षर)"
                    save()
                }
                // पूरा curl/कोड पेस्ट हुआ हो तो फ़ोकस हटते ही सिर्फ़ key रख दो
                keyEdit.setOnFocusChangeListener { _, focus ->
                    if (!focus && keyEdit.text.toString() != p.key) keyEdit.setText(p.key)
                }
                card.addView(keyEdit)
                card.addView(status)

                card.addView(ui.text("Model", 12f, Theme.textDim).apply { setPadding(0, ui.dp(10), 0, ui.dp(4)) })
                card.addView(ui.edit(p.model, false, "जैसे gemini-flash-latest") { p.model = it.trim(); save() })

                if (p.type != "gemini") {
                    card.addView(ui.text("Base URL (…/v1 तक)", 12f, Theme.textDim).apply { setPadding(0, ui.dp(10), 0, ui.dp(4)) })
                    card.addView(ui.edit(p.url, false, "https://api.openai.com/v1") { p.url = it.trim(); save() })
                }

                if (i > 0) card.addView(ui.button("⬆ ऊपर लाओ (पहले आज़माओ)") {
                    list.removeAt(i); list.add(i - 1, p); save(); render()
                })
                card.addView(ui.button("🗑 हटाओ") { list.removeAt(i); save(); render() })
                box.addView(card)
            }
        }
        render()

        col.addView(ui.text("\nनया AI जोड़ो", 14f, Theme.text, true))
        listOf(
            "gemini" to "+ Gemini (Google)",
            "openai" to "+ ChatGPT (OpenAI)",
            "groq" to "+ Groq",
            "openrouter" to "+ OpenRouter",
            "custom" to "+ कस्टम (कोई भी OpenAI-जैसा URL)"
        ).forEach { (kind, label) ->
            col.addView(ui.button(label) { list.add(ProviderConfig.preset(kind)); save(); render() })
        }
        col.addView(ui.hint("Gemini key: aistudio.google.com/apikey से सिर्फ़ AIza… वाली key कॉपी करो (curl/Python कोड नहीं)। model का नाम पुराना हो जाए तो यहीं बदल सकते हो।"))
    }
}
