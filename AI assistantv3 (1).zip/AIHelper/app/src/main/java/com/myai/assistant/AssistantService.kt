package com.myai.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.myai.assistant.core.AppState
import com.myai.assistant.core.Brain
import com.myai.assistant.core.Bus
import com.myai.assistant.core.Prefs
import com.myai.assistant.core.Stt
import com.myai.assistant.core.isOnline
import com.myai.assistant.providers.VoiceRouter
import com.myai.assistant.theme.Theme
import com.myai.assistant.ui.FloatingWindow
import com.myai.assistant.wake.PicoWake
import com.myai.assistant.wake.SpeechWake
import com.myai.assistant.wake.VoiceId
import com.myai.assistant.wake.WakeEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * पूरा असिस्टेंट यहीं जुड़ता है:
 *   नाम सुनो (wake) → पैनल खोलो → आवाज़ सुनो (Stt) → सोचो (Brain) → बोलो (Voice) → फिर सुनो।
 * शुरू करने के और रास्ते: नोटिफिकेशन बटन, Quick Settings टाइल, डॉट पर टैप, मुख्य स्क्रीन का 🎤, डिफ़ॉल्ट असिस्टेंट।
 */
class AssistantService : Service() {

    companion object {
        const val ACTION_STOP = "com.myai.assistant.STOP"
        const val ACTION_SUMMON = "com.myai.assistant.SUMMON"
        private const val CH = "assistant"

        @Volatile
        var instance: AssistantService? = null

        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, AssistantService::class.java))
            } catch (_: Exception) {
            }
        }

        fun summon(ctx: Context) {
            try {
                ContextCompat.startForegroundService(
                    ctx, Intent(ctx, AssistantService::class.java).setAction(ACTION_SUMMON)
                )
            } catch (_: Exception) {
            }
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, AssistantService::class.java))
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var prefs: Prefs
    private lateinit var brain: Brain
    private lateinit var voice: VoiceRouter
    private lateinit var stt: Stt
    private lateinit var voiceId: VoiceId
    private lateinit var floating: FloatingWindow

    private var wake: WakeEngine? = null
    private var forceSpeech = false
    private var started = false
    private var busy = false
    private var voiceMode = false
    private var job: Job? = null
    private val collapseTask = Runnable { if (!busy) collapse() }

    override fun onCreate() {
        super.onCreate()
        instance = this
        Theme.load(this)
        prefs = Prefs.of(this)
        brain = Brain(this, prefs)
        voice = VoiceRouter(this, prefs)
        stt = Stt(this, prefs)
        voiceId = VoiceId(this, prefs)
        floating = FloatingWindow(
            this,
            nameFn = { prefs.get("name") },
            onSubmit = { submit(it) },
            onMic = { micTap() },
            onExpand = { showPanel() },
            onCollapse = { collapse() }
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!goForeground()) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!started) {
            started = true
            AppState.serviceOn = true
            startWake()
        }
        if (intent?.action == ACTION_SUMMON) main.post { summon() }
        onAppVisibility()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        started = false
        AppState.serviceOn = false
        instance = null
        main.removeCallbacksAndMessages(null)
        job?.cancel()
        scope.cancel()
        stopWake()
        stt.cancel()
        voice.stop()
        voiceId.close()
        floating.set(FloatingWindow.Mode.NONE)
        Bus.setState(Bus.State.IDLE)
        super.onDestroy()
    }

    private fun goForeground(): Boolean {
        return try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH, "Assistant", NotificationManager.IMPORTANCE_LOW))
            val open = PendingIntent.getActivity(
                this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
            )
            val call = PendingIntent.getForegroundService(
                this, 2, Intent(this, AssistantService::class.java).setAction(ACTION_SUMMON), PendingIntent.FLAG_IMMUTABLE
            )
            val stop = PendingIntent.getService(
                this, 1, Intent(this, AssistantService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
            )
            val n = Notification.Builder(this, CH)
                .setContentTitle(prefs.get("name") + " तैयार है")
                .setContentText("नाम बोलो, या यहाँ 'बुलाओ' दबाओ")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(open)
                .addAction(Notification.Action.Builder(null, "बुलाओ", call).build())
                .addAction(Notification.Action.Builder(null, "रोको", stop).build())
                .setOngoing(true)
                .build()
            ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            true
        } catch (e: Exception) {
            false
        }
    }

    // ---------- बाहर से बुलाने के रास्ते (UI यही कॉल करता है) ----------

    fun submit(text: String) {
        main.post { handle(text, false) }
    }

    fun micTap() {
        main.post { summon() }
    }

    fun say(text: String) {
        scope.launch {
            try { voice.speak(text, true, isOnline(this@AssistantService)) } catch (_: Exception) {}
        }
    }

    /** settings बदलने के बाद इंजन नए सिरे से शुरू। */
    fun reload() {
        main.post {
            stopWake()
            voiceId.close()
            forceSpeech = false
            floating.set(FloatingWindow.Mode.NONE)
            if (!busy) startWake()
            onAppVisibility()
        }
    }

    fun pauseWake() {
        main.post { stopWake() }
    }

    /** ऐप स्क्रीन पर दिखे तो तैरता डॉट छिपाओ; ऐप बंद/पीछे जाए तो डॉट दिखाओ। */
    fun onAppVisibility() {
        main.post {
            if (AppState.appVisible || !started) {
                floating.set(FloatingWindow.Mode.NONE)
            } else if (canDraw() && prefs.bool("dot")) {
                if (floating.mode == FloatingWindow.Mode.NONE) floating.set(FloatingWindow.Mode.BUBBLE)
            } else {
                floating.set(FloatingWindow.Mode.NONE)
            }
        }
    }

    // ---------- नाम सुनना ----------

    private fun startWake() {
        if (!started || wake != null || VoiceId.enrolling) return
        val engine: WakeEngine =
            if (prefs.picoKey.isNotBlank() && !forceSpeech) {
                PicoWake(
                    this, prefs, voiceId,
                    onWake = { main.post { onWakeDetected() } },
                    onError = { msg -> main.post { picoFailed(msg) } }
                )
            } else {
                SpeechWake(this, prefs) { main.post { onWakeDetected() } }
            }
        wake = engine
        engine.start()
    }

    private fun stopWake() {
        wake?.stop()
        wake = null
    }

    private fun picoFailed(msg: String) {
        wake = null
        forceSpeech = true
        Bus.line("ai", "Wake word में दिक्कत: $msg। अभी फ़ोन की speech से नाम सुन रहा हूँ (Picovoice key / .ppn जाँचो)।")
        startWake()
    }

    private fun onWakeDetected() {
        wake = null
        if (!busy) summon()
    }

    // ---------- बातचीत ----------

    private fun summon() {
        main.removeCallbacks(collapseTask)
        if (busy) {
            job?.cancel()
            voice.stop()
            busy = false
        }
        showPanel()
        voiceMode = true
        listenCommand()
    }

    private fun listenCommand() {
        stopWake()
        Bus.setState(Bus.State.LISTENING)
        stt.listen(
            onResult = { t -> if (t.isBlank()) idle() else handle(t, true) },
            onFail = { idle() }
        )
    }

    private fun idle() {
        busy = false
        Bus.setState(Bus.State.IDLE)
        startWake()
        main.removeCallbacks(collapseTask)
        main.postDelayed(collapseTask, 12000)
    }

    private fun handle(text: String, fromVoice: Boolean) {
        if (busy) return
        busy = true
        voiceMode = fromVoice
        main.removeCallbacks(collapseTask)
        stt.cancel()
        stopWake()
        showPanel()
        Bus.line("you", text)
        Bus.setState(Bus.State.THINKING)

        job = scope.launch {
            val online = isOnline(this@AssistantService)
            var reply = ""
            var premium = false
            try {
                val r = brain.respond(text, online)
                reply = r.text
                premium = r.premium
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                reply = "एरर: " + (e.message ?: "unknown").take(120)
                premium = false
            }
            Bus.line("ai", reply)
            Bus.setState(Bus.State.SPEAKING)
            try {
                voice.speak(reply, premium, online)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // आवाज़ फेल हुई तो भी टेक्स्ट दिख चुका है
            }
            busy = false
            if (voiceMode) listenCommand() else idle()
        }
    }

    // ---------- तैरती विंडो ----------

    private fun canDraw() = Settings.canDrawOverlays(this)

    private fun showPanel() {
        if (!AppState.appVisible && canDraw()) floating.set(FloatingWindow.Mode.PANEL)
    }

    private fun collapse() {
        if (AppState.appVisible || !canDraw() || !prefs.bool("dot")) {
            floating.set(FloatingWindow.Mode.NONE)
        } else {
            floating.set(FloatingWindow.Mode.BUBBLE)
        }
    }
}
