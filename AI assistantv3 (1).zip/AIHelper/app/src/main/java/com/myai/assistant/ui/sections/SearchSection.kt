package com.myai.assistant.ui.sections

import android.app.Activity
import android.widget.LinearLayout
import com.myai.assistant.ui.UiKit

/** लाइव सर्च। कोई key न हो तो Gemini का अपना Google Search चलता है; वह भी न हो तो ब्राउज़र में गूगल खुलता है। */
object SearchSection {
    fun build(a: Activity, col: LinearLayout) {
        val ui = UiKit(a)
        col.addView(ui.hint("सब optional है। Gemini जुड़ा हो तो नीचे वाला स्विच ON रखो, वही लाइव जानकारी ला देगा।"))

        val c1 = ui.card()
        ui.switchRow(c1, "Gemini का Google Search (live)", "grounding")
        col.addView(c1)

        val c2 = ui.card()
        ui.field(c2, "Google Search API key (Custom Search)", "searchKey", secret = true)
        ui.field(c2, "Search Engine ID (cx)", "searchCx")
        ui.hint("cx: programmablesearchengine.google.com से; key: Google Cloud Console → Custom Search API।").also { c2.addView(it) }
        col.addView(c2)
    }
}
