package com.myai.assistant.face

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import androidx.core.graphics.ColorUtils
import com.myai.assistant.core.Bus
import kotlin.math.sin

/** रोबोट का सिर: चमकती आँखें, पलकें झपकना, बोलते समय मुँह की पट्टियाँ हिलना। */
class RobotFace : FaceRenderer {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()

    override fun draw(c: Canvas, w: Float, h: Float, t: Float, state: Bus.State, level: Float, cfg: FaceConfig) {
        val s = minOf(w, h)
        val cx = w / 2f
        val cy = h / 2f + s * 0.03f
        val hw = s * 0.64f
        val hh = s * 0.52f

        // पीछे की चमक
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(
            cx, cy, s * 0.7f,
            intArrayOf(alpha(cfg.glow, 70 + (60 * level).toInt()), alpha(cfg.glow, 0)),
            null, Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, s * 0.7f, p)

        // एंटीना
        p.shader = null
        p.color = ColorUtils.blendARGB(cfg.secondary, Color.WHITE, 0.3f)
        c.drawRect(cx - s * 0.008f, cy - hh / 2f - s * 0.10f, cx + s * 0.008f, cy - hh / 2f, p)
        p.color = alpha(cfg.primary, 150 + (105 * level).toInt())
        c.drawCircle(cx, cy - hh / 2f - s * 0.11f, s * 0.028f * (1f + 0.4f * level), p)

        // सिर (3D जैसा ग्रेडिएंट)
        r.set(cx - hw / 2f, cy - hh / 2f, cx + hw / 2f, cy + hh / 2f)
        p.shader = LinearGradient(
            r.left, r.top, r.right, r.bottom,
            intArrayOf(
                ColorUtils.blendARGB(cfg.secondary, Color.WHITE, 0.35f), cfg.secondary,
                ColorUtils.blendARGB(cfg.secondary, Color.BLACK, 0.65f)
            ),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(r, s * 0.12f, s * 0.12f, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = maxOf(2f, s * 0.012f)
        p.color = alpha(cfg.primary, 170)
        c.drawRoundRect(r, s * 0.12f, s * 0.12f, p)

        // स्क्रीन-जैसा चेहरा
        r.set(cx - hw * 0.40f, cy - hh * 0.34f, cx + hw * 0.40f, cy + hh * 0.30f)
        p.style = Paint.Style.FILL
        p.color = 0xFF050B10.toInt()
        c.drawRoundRect(r, s * 0.07f, s * 0.07f, p)

        // आँखें (हर ~4 सेकंड में पलक झपकना)
        val ph = (t * cfg.speed) % 4.2f
        val blink = if (ph > 4.05f) 0.12f else 1f
        val think = if (state == Bus.State.THINKING) 0.55f else 1f
        val ew = hw * 0.15f
        val eh = hh * 0.17f * blink * think * (1f + 0.25f * level)
        val ey = cy - hh * 0.10f
        val look = sin(t * 0.8f) * ew * 0.25f
        for (sx in intArrayOf(-1, 1)) {
            val ex = cx + sx * hw * 0.21f
            p.shader = RadialGradient(
                ex, ey, ew * 1.8f,
                intArrayOf(alpha(cfg.glow, 140), alpha(cfg.glow, 0)), null, Shader.TileMode.CLAMP
            )
            c.drawCircle(ex, ey, ew * 1.8f, p)
            p.shader = null
            p.color = cfg.primary
            r.set(ex - ew, ey - eh, ex + ew, ey + eh)
            c.drawOval(r, p)
            p.color = alpha(Color.WHITE, 220)
            c.drawCircle(ex + look, ey - eh * 0.2f, ew * 0.28f, p)
        }

        // मुँह: 7 पट्टियाँ
        val n = 7
        val bw = hw * 0.045f
        val gap = bw * 0.9f
        val total = n * bw + (n - 1) * gap
        val my = cy + hh * 0.16f
        for (i in 0 until n) {
            val phase = if (state == Bus.State.SPEAKING) 0.5f + 0.5f * sin(t * 13f + i * 1.7f) else 0.25f
            val bh = hh * (0.015f + 0.075f * phase * (0.4f + level))
            val bx = cx - total / 2f + i * (bw + gap)
            p.color = alpha(cfg.primary, 230)
            r.set(bx, my - bh, bx + bw, my + bh)
            c.drawRoundRect(r, bw / 2f, bw / 2f, p)
        }
    }
}
