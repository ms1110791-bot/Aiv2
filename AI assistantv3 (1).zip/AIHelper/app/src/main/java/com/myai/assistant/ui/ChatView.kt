package com.myai.assistant.ui

import android.content.Context
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.myai.assistant.core.Bus
import com.myai.assistant.theme.Theme

/** चैट की बातचीत दिखाने वाला View (मुख्य स्क्रीन और तैरती विंडो दोनों में यही चलता है)। */
class ChatView(ctx: Context) : ScrollView(ctx), Bus.Listener {
    private val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

    init {
        addView(col, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        isVerticalScrollBarEnabled = false
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        col.removeAllViews()
        Bus.log.forEach { add(it.first, it.second) }
        Bus.add(this)
        post { fullScroll(View.FOCUS_DOWN) }
    }

    override fun onDetachedFromWindow() {
        Bus.remove(this)
        super.onDetachedFromWindow()
    }

    override fun onLine(who: String, text: String) {
        if (who == "clear") {
            col.removeAllViews()
            return
        }
        add(who, text)
        post { fullScroll(View.FOCUS_DOWN) }
    }

    private fun add(who: String, text: String) {
        val mine = who == "you"
        val tv = TextView(context).apply {
            this.text = text
            textSize = 14f
            setTextColor(Theme.text)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = Theme.rounded(
                if (mine) Theme.accent2Dim else Theme.panelAlt, dp(14).toFloat(),
                if (mine) 0 else Theme.line, if (mine) 0 else 1
            )
        }
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            topMargin = dp(6)
            gravity = if (mine) Gravity.END else Gravity.START
            if (mine) marginStart = dp(40) else marginEnd = dp(40)
        }
        col.addView(tv, lp)
    }
}
