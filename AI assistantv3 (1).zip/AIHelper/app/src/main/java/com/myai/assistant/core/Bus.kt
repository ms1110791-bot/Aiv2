package com.myai.assistant.core

import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArraySet

/** ऐप की साझा स्थिति (कौन सी स्क्रीन दिख रही है, सर्विस चालू है या नहीं)। */
object AppState {
    @Volatile var appVisible = false
    @Volatile var serviceOn = false
}

/** UI और सर्विस के बीच संदेश: AI की स्थिति और चैट की लाइनें। सारे listener main thread पर चलते हैं। */
object Bus {
    enum class State { IDLE, LISTENING, THINKING, SPEAKING }

    interface Listener {
        fun onState(s: State) {}
        fun onLine(who: String, text: String) {}
    }

    private val ls = CopyOnWriteArraySet<Listener>()
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    var state = State.IDLE
        private set

    /** (who, text): who = "you" या "ai"। सिर्फ़ main thread से छुओ। */
    val log = ArrayList<Pair<String, String>>()

    fun add(l: Listener) { ls.add(l) }
    fun remove(l: Listener) { ls.remove(l) }

    fun setState(s: State) {
        state = s
        main.post { ls.forEach { it.onState(s) } }
    }

    fun line(who: String, text: String) {
        main.post {
            log.add(who to text)
            while (log.size > 60) log.removeAt(0)
            ls.forEach { it.onLine(who, text) }
        }
    }

    fun clear() {
        main.post {
            log.clear()
            ls.forEach { it.onLine("clear", "") }
        }
    }
}
