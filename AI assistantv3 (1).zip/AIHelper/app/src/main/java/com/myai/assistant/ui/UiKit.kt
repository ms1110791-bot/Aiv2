package com.myai.assistant.ui

import android.content.Context
import android.graphics.Typeface
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import com.myai.assistant.core.Prefs
import com.myai.assistant.theme.Theme

/** स्क्रीनें बनाने के छोटे औज़ार (एक जगह, ताकि लुक एक जैसा रहे)। */
class UiKit(val ctx: Context) {
    fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    fun text(s: String, size: Float = 14f, color: Int = Theme.text, bold: Boolean = false): TextView =
        TextView(ctx).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    fun title(s: String): TextView = text(s, 22f, Theme.accent, true).apply { letterSpacing = 0.1f }

    fun hint(s: String): TextView = text(s, 12f, Theme.textDim).apply { setPadding(0, dp(4), 0, dp(4)) }

    fun gap(h: Int): android.view.View = android.view.View(ctx).apply {
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(h))
    }

    fun card(): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(14))
        background = Theme.rounded(Theme.panel, dp(16).toFloat(), Theme.line, dp(1))
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(12) }
    }

    fun button(label: String, onClick: () -> Unit): Button = Button(ctx).apply {
        text = label
        isAllCaps = false
        setTextColor(Theme.accent)
        textSize = 14f
        background = Theme.rounded(Theme.panelAlt, dp(12).toFloat(), Theme.accent, dp(1))
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(46)
        ).apply { topMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    fun edit(initial: String, secret: Boolean, hintText: String = "", onChange: (String) -> Unit): EditText =
        EditText(ctx).apply {
            setText(initial)
            hint = hintText
            setHintTextColor(Theme.textDim)
            setTextColor(Theme.text)
            textSize = 14f
            setSingleLine()
            inputType = if (secret) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            else InputType.TYPE_CLASS_TEXT
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = Theme.rounded(Theme.panelAlt, dp(10).toFloat())
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { onChange(s?.toString().orEmpty()) }
            })
        }

    /** टेक्स्ट बॉक्स जो हर बदलाव पर अपने-आप सेव होता है (अलग सेव बटन नहीं चाहिए)। */
    fun field(parent: ViewGroup, label: String, key: String, secret: Boolean = false) {
        val prefs = Prefs.of(ctx)
        parent.addView(text(label, 12f, Theme.textDim).apply { setPadding(0, dp(12), 0, dp(4)) })
        val status = hint("")
        fun refresh(v: String) {
            if (secret) status.text = if (v.isBlank()) "खाली" else "✓ सेव (${v.length} अक्षर)"
        }
        val e = edit(prefs.get(key), secret) { v -> prefs.put(key, v); refresh(v) }
        parent.addView(e)
        if (secret) {
            refresh(prefs.get(key))
            parent.addView(status)
        }
    }

    fun switchRow(parent: ViewGroup, label: String, key: String, onChange: (() -> Unit)? = null): Switch {
        val prefs = Prefs.of(ctx)
        val s = Switch(ctx).apply {
            text = label
            setTextColor(Theme.text)
            textSize = 14f
            isChecked = prefs.bool(key)
            setPadding(0, dp(10), 0, dp(10))
            gravity = Gravity.CENTER_VERTICAL
            setOnCheckedChangeListener { _, on -> prefs.putBool(key, on); onChange?.invoke() }
        }
        parent.addView(s)
        return s
    }
}
