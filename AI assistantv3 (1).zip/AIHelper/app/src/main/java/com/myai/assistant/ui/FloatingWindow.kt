package com.myai.assistant.ui

import android.content.Context
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.myai.assistant.face.FaceView
import com.myai.assistant.face.alpha
import com.myai.assistant.theme.Theme
import kotlin.math.abs

/**
 * ऐप बंद होने पर स्क्रीन पर तैरने वाला UI।
 * BUBBLE = छोटा गोल डॉट (चेहरे के साथ; खिसका सकते हो; टैप करो तो खुलता है)
 * PANEL  = छोटी चैट विंडो (लिख सकते हो, 🎤 दबा सकते हो)
 */
class FloatingWindow(
    private val ctx: Context,
    private val nameFn: () -> String,
    private val onSubmit: (String) -> Unit,
    private val onMic: () -> Unit,
    private val onExpand: () -> Unit,
    private val onCollapse: () -> Unit
) {
    enum class Mode { NONE, BUBBLE, PANEL }

    var mode = Mode.NONE
        private set

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var view: View? = null

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun lp(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private val bubbleLp = lp(dp(64), dp(64)).apply { x = dp(8); y = dp(220) }
    private val panelLp = lp(
        minOf(dp(330), ctx.resources.displayMetrics.widthPixels - dp(24)),
        WindowManager.LayoutParams.WRAP_CONTENT
    ).apply { x = dp(12); y = dp(140) }

    fun set(m: Mode) {
        if (m == mode) return
        view?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        view = null
        mode = Mode.NONE
        if (m == Mode.NONE) return
        try {
            val v = if (m == Mode.BUBBLE) buildBubble() else buildPanel()
            wm.addView(v, if (m == Mode.BUBBLE) bubbleLp else panelLp)
            view = v
            mode = m
        } catch (_: Exception) {
            // overlay permission नहीं है
        }
    }

    /** खींचने और टैप को अलग पहचानता है। */
    private fun drag(target: View, params: WindowManager.LayoutParams, root: View, onTap: (() -> Unit)?) {
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        target.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = params.x; sy = params.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx
                    val dy = e.rawY - ty
                    if (abs(dx) > dp(8) || abs(dy) > dp(8)) moved = true
                    if (moved) {
                        params.x = sx + dx.toInt()
                        params.y = sy + dy.toInt()
                        try { wm.updateViewLayout(root, params) } catch (_: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) onTap?.invoke()
            }
            true
        }
    }

    private fun buildBubble(): View {
        val box = FrameLayout(ctx).apply {
            background = Theme.rounded(alpha(Theme.bg, 235), dp(32).toFloat(), Theme.accent, dp(2))
            addView(FaceView(ctx), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        drag(box, bubbleLp, box) { onExpand() }
        return box
    }

    private fun buildPanel(): View {
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(12))
            background = Theme.rounded(alpha(Theme.bg, 245), dp(22).toFloat(), Theme.accent, dp(1))
        }

        val head = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(FaceView(ctx), LinearLayout.LayoutParams(dp(44), dp(44)))
        head.addView(TextView(ctx).apply {
            text = nameFn().uppercase()
            setTextColor(Theme.accent)
            textSize = 14f
            letterSpacing = 0.2f
            setPadding(dp(8), 0, 0, 0)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(TextView(ctx).apply {
            text = "—"
            setTextColor(Theme.text)
            textSize = 22f
            setPadding(dp(16), dp(2), dp(8), dp(2))
            setOnClickListener { onCollapse() }
        })
        drag(head, panelLp, col, null)

        val chat = ChatView(ctx)

        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val input = EditText(ctx).apply {
            hint = "यहाँ लिखो…"
            setHintTextColor(Theme.textDim)
            setTextColor(Theme.text)
            textSize = 14f
            maxLines = 2
            imeOptions = EditorInfo.IME_ACTION_SEND
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = Theme.rounded(Theme.panelAlt, dp(18).toFloat())
        }
        input.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                // लिखने के लिए विंडो को keyboard लेने दो
                panelLp.flags = panelLp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
                try { wm.updateViewLayout(col, panelLp) } catch (_: Exception) {}
            }
            false
        }
        fun send() {
            val t = input.text.toString().trim()
            input.setText("")
            panelLp.flags = panelLp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            try { wm.updateViewLayout(col, panelLp) } catch (_: Exception) {}
            (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .hideSoftInputFromWindow(input.windowToken, 0)
            if (t.isNotEmpty()) onSubmit(t)
        }
        input.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEND) { send(); true } else false
        }
        fun round(label: String, fill: Int, onClick: () -> Unit) = TextView(ctx).apply {
            text = label
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Theme.bg)
            background = Theme.rounded(fill, dp(22).toFloat())
            setOnClickListener { onClick() }
        }
        row.addView(input, LinearLayout.LayoutParams(0, dp(44), 1f))
        row.addView(round("🎤", Theme.accent) { onMic() }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginStart = dp(6) })
        row.addView(round("➤", Theme.ok) { send() }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginStart = dp(6) })

        col.addView(head)
        col.addView(chat, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(170)))
        col.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        return col
    }
}
