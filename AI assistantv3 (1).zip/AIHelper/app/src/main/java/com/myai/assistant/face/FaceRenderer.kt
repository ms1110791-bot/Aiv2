package com.myai.assistant.face

import android.graphics.Canvas
import com.myai.assistant.core.Bus

/** हर चेहरा एक FaceRenderer है। नया चेहरा = नई फ़ाइल + forType() में एक लाइन। */
interface FaceRenderer {
    fun draw(c: Canvas, w: Float, h: Float, t: Float, state: Bus.State, level: Float, cfg: FaceConfig)

    companion object {
        fun forType(type: String): FaceRenderer = when (type) {
            "robot" -> RobotFace()
            "holo" -> HoloFace()
            else -> OrbFace()
        }
    }
}

fun alpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)
