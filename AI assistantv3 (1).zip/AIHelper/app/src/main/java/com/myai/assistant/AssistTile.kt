package com.myai.assistant

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** नोटिफिकेशन पैनल की Quick Settings टाइल: एक टैप में AI को बुलाओ (नाम बोले बिना)। */
class AssistTile : TileService() {
    override fun onStartListening() {
        qsTile?.apply {
            state = Tile.STATE_INACTIVE
            label = "AI Helper"
            updateTile()
        }
    }

    override fun onClick() {
        AssistantService.summon(applicationContext)
    }
}
