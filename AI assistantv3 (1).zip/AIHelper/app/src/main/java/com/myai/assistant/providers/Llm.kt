package com.myai.assistant.providers

import com.myai.assistant.core.Http
import com.myai.assistant.core.Prefs
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/*
 * AI जोड़ना/बदलना: menu → AI APIs से (कोड नहीं छूना)।
 * बिल्कुल नया तरह का AI चाहिए तो नीचे LlmProvider implement करो और LlmRouter.build() में एक लाइन जोड़ो।
 */

class ProviderConfig(
    var type: String,           // "gemini" या "openai" (OpenAI-जैसा API: ChatGPT, Groq, OpenRouter, कस्टम)
    var name: String,
    var key: String = "",
    var model: String = "",
    var url: String = ""
) {
    fun toJson(): JSONObject = JSONObject()
        .put("type", type).put("name", name).put("key", key).put("model", model).put("url", url)

    companion object {
        fun from(o: JSONObject) = ProviderConfig(
            o.optString("type"), o.optString("name"), o.optString("key"), o.optString("model"), o.optString("url")
        )

        fun preset(kind: String): ProviderConfig = when (kind) {
            "gemini" -> ProviderConfig("gemini", "Gemini", "", "gemini-flash-latest", "")
            "openai" -> ProviderConfig("openai", "ChatGPT", "", "gpt-4o-mini", "https://api.openai.com/v1")
            "groq" -> ProviderConfig("openai", "Groq", "", "llama-3.3-70b-versatile", "https://api.groq.com/openai/v1")
            "openrouter" -> ProviderConfig("openai", "OpenRouter", "", "openai/gpt-4o-mini", "https://openrouter.ai/api/v1")
            else -> ProviderConfig("openai", "Custom", "", "", "")
        }
    }
}

object Keys {
    private val gem = Regex("AIza[0-9A-Za-z_\\-]{30,}")

    /** पूरा curl/कोड पेस्ट हो जाए तब भी सिर्फ़ key निकाल लेता है। */
    fun clean(raw: String, type: String): String {
        if (type == "gemini") gem.find(raw)?.let { return it.value }
        return raw.trim().removePrefix("Bearer ").filter { !it.isWhitespace() && it != '"' && it != '\'' }
    }
}

interface LlmProvider {
    suspend fun ask(
        system: String,
        user: String,
        history: List<Pair<String, String>>,
        webContext: String?,
        grounding: Boolean
    ): String
}

class GeminiLlm(private val c: ProviderConfig) : LlmProvider {
    override suspend fun ask(
        system: String, user: String, history: List<Pair<String, String>>,
        webContext: String?, grounding: Boolean
    ): String = withContext(Dispatchers.IO) {
        val contents = JSONArray()
        history.takeLast(6).forEach { (role, text) ->
            contents.put(
                JSONObject().put("role", role)
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        val finalUser = if (webContext != null) user + "\n\n[Web results]\n" + webContext else user
        contents.put(
            JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", finalUser)))
        )
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
        if (grounding) body.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
        val url = "https://generativelanguage.googleapis.com/v1beta/models/" + c.model.ifBlank { "gemini-flash-latest" } + ":generateContent"
        val res = Http.request(url, "POST", body.toString(), mapOf("Content-Type" to "application/json", "x-goog-api-key" to c.key))
        val parts = JSONObject(String(res))
            .getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        buildString {
            for (i in 0 until parts.length()) append(parts.getJSONObject(i).optString("text"))
        }.trim()
    }
}

/** OpenAI-जैसा chat/completions API: ChatGPT, Groq, OpenRouter, LM Studio, कोई भी कस्टम URL। */
class OpenAiLlm(private val c: ProviderConfig) : LlmProvider {
    override suspend fun ask(
        system: String, user: String, history: List<Pair<String, String>>,
        webContext: String?, grounding: Boolean
    ): String = withContext(Dispatchers.IO) {
        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put("content", system))
        history.takeLast(6).forEach { (role, text) ->
            msgs.put(JSONObject().put("role", if (role == "model") "assistant" else "user").put("content", text))
        }
        val finalUser = if (webContext != null) user + "\n\n[Web results]\n" + webContext else user
        msgs.put(JSONObject().put("role", "user").put("content", finalUser))
        val body = JSONObject().put("model", c.model).put("messages", msgs).put("max_tokens", 300)
        val base = c.url.ifBlank { "https://api.openai.com/v1" }.trimEnd('/')
        val res = Http.request(
            "$base/chat/completions", "POST", body.toString(),
            mapOf("Content-Type" to "application/json", "Authorization" to "Bearer " + c.key)
        )
        JSONObject(String(res)).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").optString("content").trim()
    }
}

/** सूची में ऊपर से नीचे AI आज़माता है; एक फेल हो तो अगला। */
class LlmRouter(private val prefs: Prefs) {
    private fun usable() = prefs.providers().filter { it.key.isNotBlank() }

    fun configured() = usable().isNotEmpty()

    private fun build(c: ProviderConfig): LlmProvider = when (c.type) {
        "gemini" -> GeminiLlm(c)
        else -> OpenAiLlm(c)
    }

    suspend fun ask(
        system: String, user: String, history: List<Pair<String, String>>,
        webContext: String?, grounding: Boolean
    ): String {
        var last: Exception? = null
        for (c in usable()) {
            try {
                val r = build(c).ask(system, user, history, webContext, grounding && c.type == "gemini")
                if (r.isNotBlank()) return r
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: RuntimeException("कोई AI जवाब नहीं दे पाया")
    }
}
