package com.myai.assistant.theme

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import org.json.JSONObject

/**
 * रंग यहाँ नहीं, assets/styles/jarvis.json में बदलो। कोड छूने की ज़रूरत नहीं।
 * नई theme चाहिए तो वही फ़ाइल कॉपी करके रंग बदल दो।
 */
object Theme {
    var bg = 0xFF050B14.toInt()
    var bg2 = 0xFF0A1830.toInt()
    var panel = 0xFF0B1626.toInt()
    var panelAlt = 0xFF10233A.toInt()
    var accent = 0xFF00E5FF.toInt()
    var accent2 = 0xFF2979FF.toInt()
    var accent2Dim = 0xFF16397A.toInt()
    var text = 0xFFE6F7FF.toInt()
    var textDim = 0xFF7FA6BF.toInt()
    var line = 0xFF1B4A66.toInt()
    var danger = 0xFFFF5252.toInt()
    var ok = 0xFF69F0AE.toInt()

    fun load(ctx: Context) {
        try {
            val j = JSONObject(ctx.assets.open("styles/jarvis.json").bufferedReader().use { it.readText() })
            fun c(k: String, d: Int): Int = try { Color.parseColor(j.getString(k)) } catch (e: Exception) { d }
            bg = c("bg", bg); bg2 = c("bg2", bg2); panel = c("panel", panel); panelAlt = c("panelAlt", panelAlt)
            accent = c("accent", accent); accent2 = c("accent2", accent2); accent2Dim = c("accent2Dim", accent2Dim)
            text = c("text", text); textDim = c("textDim", textDim); line = c("line", line)
            danger = c("danger", danger); ok = c("ok", ok)
        } catch (_: Exception) {
        }
    }

    fun rounded(fill: Int, radius: Float, stroke: Int = 0, strokeW: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = radius
            if (strokeW > 0) setStroke(strokeW, stroke)
        }

    fun backdrop(): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(bg, bg2, bg))
}
