package com.myai.assistant.ui.sections

import android.app.Activity
import android.widget.LinearLayout
import com.myai.assistant.AssistantService
import com.myai.assistant.ui.UiKit

/** बोलने वाली आवाज़: ElevenLabs (ऑनलाइन) या फ़ोन की अपनी आवाज़ (ऑफलाइन)। */
object VoiceSection {
    fun build(a: Activity, col: LinearLayout) {
        val ui = UiKit(a)
        col.addView(ui.hint("key न हो तो फ़ोन की अपनी आवाज़ बोलेगी (ऑफलाइन भी चलती है)। ElevenLabs key डालने पर ऑनलाइन में वही बोलेगा।"))

        val card = ui.card()
        ui.switchRow(card, "ElevenLabs आवाज़ चालू", "useEleven")
        ui.field(card, "ElevenLabs API key", "elevenKey", secret = true)
        ui.field(card, "Voice ID", "elevenVoice")
        ui.field(card, "Model", "elevenModel")
        col.addView(card)

        val card2 = ui.card()
        ui.field(card2, "भाषा कोड (hi-IN / en-IN)", "lang")
        col.addView(card2)

        col.addView(ui.button("🔊 आवाज़ टेस्ट करो") {
            AssistantService.instance?.say("नमस्ते, मैं तैयार हूँ") ?: AssistantService.start(a)
        })
    }
}
