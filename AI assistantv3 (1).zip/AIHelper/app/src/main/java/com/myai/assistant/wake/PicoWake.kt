package com.myai.assistant.wake

import ai.picovoice.porcupine.Porcupine
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import com.myai.assistant.core.Bus
import com.myai.assistant.core.Prefs
import java.io.File

/**
 * Porcupine से नाम सुनना। माइक एक बार खुलता है और नाम मिलने तक लगातार ON रहता है।
 * नाम मिलने पर (और Voice-ID चालू हो तो आवाज़ मिलने पर) माइक छोड़ देता है ताकि कमांड सुनी जा सके।
 */
class PicoWake(
    private val ctx: Context,
    private val prefs: Prefs,
    private val gate: VoiceId?,
    private val onWake: () -> Unit,
    private val onError: (String) -> Unit
) : WakeEngine {

    @Volatile private var run = false
    private var th: Thread? = null

    override fun start() {
        if (run) return
        run = true
        th = Thread({ loop() }, "wake-engine").also { it.start() }
    }

    override fun stop() {
        run = false
        val t = th
        if (t != null && t !== Thread.currentThread()) {
            try { t.join(1000) } catch (_: Exception) {}
        }
        th = null
    }

    private fun build(): Porcupine {
        val b = Porcupine.Builder().setAccessKey(prefs.picoKey)
        val ppn = prefs.get("picoPpn")
        if (ppn.isNotBlank() && File(ppn).exists()) {
            b.setKeywordPaths(arrayOf(ppn))
        } else {
            b.setKeywords(arrayOf(Porcupine.BuiltInKeyword.valueOf(prefs.get("picoKeyword"))))
        }
        val pv = prefs.get("picoModel")
        if (pv.isNotBlank() && File(pv).exists()) b.setModelPath(pv)
        return b.build(ctx)
    }

    private fun loop() {
        var porcupine: Porcupine? = null
        var rec: AudioRecord? = null
        var woke = false
        var failure: String? = null
        try {
            val pc = build()
            porcupine = pc
            val frame = pc.frameLength
            val minBuf = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val ar = AudioRecord(
                MediaRecorder.AudioSource.MIC, 16000, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, frame * 8)
            )
            rec = ar
            if (ar.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("माइक नहीं खुला (permission देखो)")
            ar.startRecording()

            val buf = ShortArray(frame)
            val ring = ShortArray(16000 * 3)
            var w = 0
            var count = 0

            fun push(a: ShortArray) {
                for (s in a) {
                    ring[w] = s
                    w = (w + 1) % ring.size
                }
                count = minOf(count + a.size, ring.size)
            }

            fun readFrame(): Boolean {
                var n = 0
                while (n < frame && run) {
                    val r = ar.read(buf, n, frame - n)
                    if (r < 0) throw IllegalStateException("माइक error $r")
                    n += r
                }
                return n == frame
            }

            while (run) {
                if (!readFrame()) break
                push(buf)
                if (pc.process(buf) >= 0) {
                    var ok = true
                    val g = gate
                    if (g != null && g.active()) {
                        // नाम के बाद आधा सेकंड और रिकॉर्ड करो ताकि आवाज़ जाँचने को पूरा नमूना मिले
                        var extra = 0
                        while (run && extra < 8000) {
                            if (!readFrame()) break
                            push(buf)
                            extra += frame
                        }
                        val snap = ShortArray(count)
                        val start = (w - count + ring.size) % ring.size
                        for (i in 0 until count) snap[i] = ring[(start + i) % ring.size]
                        ok = g.verify(snap)
                        if (!ok) Bus.line("ai", "(आवाज़ नहीं पहचानी, इसलिए नहीं जागा)")
                    }
                    if (ok) {
                        woke = true
                        break
                    }
                }
            }
        } catch (e: Throwable) {
            if (run) failure = e.message ?: e.javaClass.simpleName
        } finally {
            try { rec?.stop() } catch (_: Exception) {}
            try { rec?.release() } catch (_: Exception) {}
            try { porcupine?.delete() } catch (_: Exception) {}
        }
        // माइक छूटने के बाद ही बताओ, ताकि अगला कदम माइक न माँगे जब तक वह बंद न हो
        if (run) {
            run = false
            if (failure != null) onError(failure) else if (woke) onWake()
        }
    }
}
