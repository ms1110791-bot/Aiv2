package com.myai.assistant.core

import android.content.Context
import com.myai.assistant.providers.GoogleSearch
import com.myai.assistant.providers.LlmRouter
import kotlinx.coroutines.CancellationException

/** सवाल को समझकर जवाब बनाता है: ऑफलाइन कमांड → (AI न हो तो) ब्राउज़र सर्च → AI + लाइव सर्च। */
class Brain(ctx: Context, private val prefs: Prefs) {
    data class Result(val text: String, val premium: Boolean)

    private val llm = LlmRouter(prefs)
    private val search = GoogleSearch(prefs)
    val device = DeviceController(ctx)
    private val history = mutableListOf<Pair<String, String>>()

    private val needsSearch = Regex(
        "search|सर्च|खोज|google|गूगल|news|न्यूज|समाचार|latest|आज|aaj|अभी|abhi|price|भाव|कीमत|weather|मौसम|score|स्कोर|live|लाइव",
        RegexOption.IGNORE_CASE
    )
    private val stripWords = Regex("\\b(search|google)\\b|सर्च|गूगल", RegexOption.IGNORE_CASE)

    suspend fun respond(text: String, online: Boolean): Result {
        OfflineMatcher.match(text)?.let { acts ->
            val notes = acts.mapNotNull { device.run(it) }
            return Result(if (notes.isEmpty()) "हो गया" else notes.joinToString(". "), false)
        }
        if (!online) {
            return Result("इंटरनेट नहीं है। अभी सिर्फ़ फ़ोन कमांड चलेंगे, जैसे वाई-फाई, वॉल्यूम, टॉर्च।", false)
        }
        if (!llm.configured()) {
            val q = text.replace(stripWords, " ").trim().ifBlank { text }
            device.run(Act("websearch", q))
            return Result("AI key नहीं है, इसलिए ब्राउज़र में गूगल सर्च खोल दिया। AI के लिए मेन्यू में AI APIs जोड़ो।", false)
        }
        val web = if (prefs.get("searchKey").isNotBlank() && needsSearch.containsMatchIn(text)) {
            try { search.search(text) } catch (e: CancellationException) { throw e } catch (e: Exception) { null }
        } else null
        val raw = llm.ask(
            Prompts.system(prefs.get("name")), text, history, web,
            grounding = web == null && prefs.bool("grounding")
        )
        val (spoken, acts) = ActionParser.parse(raw)
        val notes = acts.mapNotNull { device.run(it) }
        val reply = if (spoken.isNotBlank()) spoken else if (notes.isEmpty()) "ठीक है" else notes.joinToString(". ")
        history.add("user" to text)
        history.add("model" to reply)
        return Result(reply, true)
    }
}
