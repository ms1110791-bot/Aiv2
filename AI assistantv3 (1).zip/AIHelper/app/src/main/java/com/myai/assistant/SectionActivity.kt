package com.myai.assistant

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import com.myai.assistant.theme.Theme
import com.myai.assistant.ui.UiKit
import com.myai.assistant.ui.sections.AiSection
import com.myai.assistant.ui.sections.FaceSection
import com.myai.assistant.ui.sections.PermsSection
import com.myai.assistant.ui.sections.SearchSection
import com.myai.assistant.ui.sections.VoiceIdSection
import com.myai.assistant.ui.sections.VoiceSection
import com.myai.assistant.ui.sections.WakeSection

/** ⋮ मेन्यू के हर हिस्से की अलग स्क्रीन। नया हिस्सा = ui/sections/ में नई फ़ाइल + नीचे `when` में एक लाइन। */
class SectionActivity : Activity() {

    private lateinit var col: LinearLayout
    private lateinit var key: String
    private var pending: ((Uri?) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Theme.load(this)
        key = intent.getStringExtra("s") ?: "ai"
        window.statusBarColor = Theme.bg
        window.navigationBarColor = Theme.bg
        val ui = UiKit(this)
        col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(16), ui.dp(14), ui.dp(16), ui.dp(48))
        }
        val sv = ScrollView(this).apply {
            background = Theme.backdrop()
            fitsSystemWindows = true
            isFillViewport = true
            addView(col, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        rebuild()
    }

    override fun onPause() {
        super.onPause()
        AssistantService.instance?.reload()
    }

    fun rebuild() {
        val ui = UiKit(this)
        col.removeAllViews()
        col.addView(ui.text("‹ वापस", 14f, Theme.textDim).apply {
            setPadding(0, ui.dp(4), ui.dp(16), ui.dp(10))
            setOnClickListener { finish() }
        })
        when (key) {
            "ai" -> { col.addView(ui.title("AI APIs")); AiSection.build(this, col) }
            "voice" -> { col.addView(ui.title("आवाज़ (Voice) API")); VoiceSection.build(this, col) }
            "search" -> { col.addView(ui.title("सर्च API")); SearchSection.build(this, col) }
            "wake" -> { col.addView(ui.title("नाम / Wake word")); WakeSection.build(this, col) }
            "voiceid" -> { col.addView(ui.title("मेरी आवाज़ पहचान")); VoiceIdSection.build(this, col) }
            "face" -> { col.addView(ui.title("AI का चेहरा")); FaceSection.build(this, col) }
            else -> { col.addView(ui.title("Permissions")); PermsSection.build(this, col) }
        }
    }

    /** फ़ाइल चुनने वाला (wake word की .ppn/.pv चुनने के लिए)। */
    fun pick(cb: (Uri?) -> Unit) {
        pending = cb
        startActivityForResult(
            Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 77
        )
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77) {
            val cb = pending
            pending = null
            cb?.invoke(if (resultCode == RESULT_OK) data?.data else null)
        }
    }
}
