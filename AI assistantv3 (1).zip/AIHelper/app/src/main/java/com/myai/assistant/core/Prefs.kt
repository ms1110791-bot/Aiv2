package com.myai.assistant.core

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.myai.assistant.providers.ProviderConfig
import org.json.JSONArray
import org.json.JSONObject

/** सारी settings (encrypted)। नई setting जोड़नी हो तो DEFAULTS में एक लाइन जोड़ो। */
class Prefs private constructor(ctx: Context) {

    companion object {
        val DEFAULTS = mapOf(
            "name" to "Jarvis",
            "wake" to "jarvis, जार्विस",
            "lang" to "hi-IN",
            "picoKey" to "",
            "picoKeyword" to "JARVIS",
            "picoPpn" to "",
            "picoModel" to "",
            "voiceIdOn" to "0",
            "voiceIdTh" to "0.5",
            "elevenKey" to "",
            "elevenVoice" to "21m00Tcm4TlvDq8ikWAM",
            "elevenModel" to "eleven_flash_v2_5",
            "useEleven" to "1",
            "searchKey" to "",
            "searchCx" to "",
            "grounding" to "1",
            "face" to "orb",
            "dot" to "1",
            "enabled" to "1"
        )

        @Volatile
        private var inst: Prefs? = null

        fun of(ctx: Context): Prefs =
            inst ?: synchronized(this) { inst ?: Prefs(ctx.applicationContext).also { inst = it } }
    }

    private val sp: SharedPreferences = try {
        val key = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            ctx, "secure_prefs_v2", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        ctx.getSharedPreferences("plain_prefs_v2", Context.MODE_PRIVATE)
    }

    fun get(k: String): String =
        sp.getString(k, null)?.takeIf { it.isNotBlank() } ?: DEFAULTS[k] ?: ""

    fun put(k: String, v: String) {
        sp.edit().putString(k, v.trim()).apply()
    }

    fun bool(k: String) = get(k) == "1"
    fun putBool(k: String, v: Boolean) = put(k, if (v) "1" else "0")

    val picoKey get() = get("picoKey")
    val threshold get() = get("voiceIdTh").toFloatOrNull() ?: 0.5f

    fun providers(): MutableList<ProviderConfig> {
        val s = sp.getString("providers", null) ?: return mutableListOf()
        return try {
            val a = JSONArray(s)
            MutableList(a.length()) { ProviderConfig.from(a.getJSONObject(it)) }
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun saveProviders(list: List<ProviderConfig>) {
        val a = JSONArray()
        list.forEach { a.put(it.toJson()) }
        sp.edit().putString("providers", a.toString()).apply()
    }
}
