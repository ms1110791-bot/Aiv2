package com.myai.assistant.core

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import java.net.HttpURLConnection
import java.net.URL

object Http {
    fun request(
        url: String,
        method: String = "GET",
        body: String? = null,
        headers: Map<String, String> = emptyMap(),
        timeoutMs: Int = 25000
    ): ByteArray {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            // header में नई लाइन/अजीब अक्षर जाने से crash होता है, इसलिए साफ़ करके भेजो
            headers.forEach { (k, v) -> c.setRequestProperty(k, v.filter { it.code in 32..126 }) }
            if (body != null) {
                c.doOutput = true
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val bytes = stream?.use { it.readBytes() } ?: ByteArray(0)
            if (code !in 200..299) throw RuntimeException("HTTP $code: " + String(bytes).take(160))
            return bytes
        } finally {
            c.disconnect()
        }
    }
}

fun isOnline(ctx: Context): Boolean {
    val cm = ctx.getSystemService(ConnectivityManager::class.java)
    val nc = cm.getNetworkCapabilities(cm.activeNetwork)
    return nc?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
}
