package com.myai.assistant.wake

import ai.picovoice.eagle.Eagle
import ai.picovoice.eagle.EagleProfile
import ai.picovoice.eagle.EagleProfiler
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import com.myai.assistant.core.Prefs
import java.io.File

/**
 * आपकी आवाज़ की पहचान (Picovoice Eagle, ऑन-डिवाइस)।
 * एक बार आवाज़ रजिस्टर करो; फिर नाम बोलने पर सिर्फ़ आपकी आवाज़ से AI जागेगा।
 */
class VoiceId(private val ctx: Context, private val prefs: Prefs) {

    companion object {
        @Volatile var enrolling = false
    }

    private val file = File(ctx.filesDir, "voice.profile")
    private var eagle: Eagle? = null
    private var profile: EagleProfile? = null

    fun hasProfile() = file.exists()

    fun active() = prefs.bool("voiceIdOn") && hasProfile() && prefs.picoKey.isNotBlank()

    fun deleteProfile() {
        close()
        file.delete()
    }

    /** जाँच नहीं हो पाई (नमूना छोटा, कोई error) तो true लौटाता है ताकि AI अटके नहीं। */
    fun verify(pcm: ShortArray): Boolean {
        return try {
            if (eagle == null) {
                eagle = Eagle.Builder().setAccessKey(prefs.picoKey).build(ctx)
                profile = EagleProfile(file.readBytes())
            }
            val e = eagle!!
            if (pcm.size < e.minProcessSamples) return true
            val scores = e.process(pcm, arrayOf(profile!!)) ?: return true
            scores.isNotEmpty() && scores[0] >= prefs.threshold
        } catch (t: Throwable) {
            true
        }
    }

    fun close() {
        try { eagle?.delete() } catch (_: Throwable) {}
        try { profile?.delete() } catch (_: Throwable) {}
        eagle = null
        profile = null
    }

    /** 100% होने तक बोलते रहना होता है (करीब 20-30 सेकंड)। */
    fun enroll(onProgress: (Int) -> Unit, onDone: (Boolean, String) -> Unit) {
        val main = Handler(Looper.getMainLooper())
        enrolling = true
        Thread({
            var prof: EagleProfiler? = null
            var rec: AudioRecord? = null
            var ok = false
            var msg = ""
            try {
                Thread.sleep(600) // पुराना माइक छूटने का इंतज़ार
                prof = EagleProfiler.Builder().setAccessKey(prefs.picoKey).build(ctx)
                val frame = prof.frameLength
                val minBuf = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                rec = AudioRecord(
                    MediaRecorder.AudioSource.MIC, 16000, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, frame * 8)
                )
                if (rec.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("माइक नहीं खुला")
                rec.startRecording()
                val buf = ShortArray(frame)
                var pct = 0f
                val end = System.currentTimeMillis() + 150_000
                while (pct < 100f && System.currentTimeMillis() < end) {
                    var n = 0
                    while (n < frame) {
                        val r = rec.read(buf, n, frame - n)
                        if (r < 0) throw IllegalStateException("माइक error $r")
                        n += r
                    }
                    pct = prof.enroll(buf)
                    val shown = pct.toInt().coerceIn(0, 100)
                    main.post { onProgress(shown) }
                }
                if (pct < 100f) throw IllegalStateException("समय ख़त्म, शांत जगह में फिर कोशिश करो")
                val p = prof.export()
                file.writeBytes(p.bytes)
                try { p.delete() } catch (_: Throwable) {}
                ok = true
                msg = "आवाज़ सेव हो गई"
            } catch (t: Throwable) {
                msg = "रजिस्टर नहीं हुई: " + (t.message ?: t.javaClass.simpleName)
            } finally {
                try { rec?.stop() } catch (_: Throwable) {}
                try { rec?.release() } catch (_: Throwable) {}
                try { prof?.delete() } catch (_: Throwable) {}
                enrolling = false
            }
            main.post { onDone(ok, msg) }
        }, "enroll").start()
    }
}
