package com.myai.assistant.ui.sections

import android.app.Activity
import android.view.ViewGroup
import android.widget.LinearLayout
import com.myai.assistant.AssistantService
import com.myai.assistant.core.Prefs
import com.myai.assistant.face.FaceConfig
import com.myai.assistant.face.FaceView
import com.myai.assistant.theme.Theme
import com.myai.assistant.ui.UiKit

/** चेहरा चुनो। नया चेहरा: assets/faces/ में नई .json डालो, यहाँ अपने-आप दिखेगा। */
object FaceSection {
    fun build(a: Activity, col: LinearLayout) {
        val ui = UiKit(a)
        val prefs = Prefs.of(a)
        val current = prefs.get("face")
        col.addView(ui.hint("जिस पर टैप करोगे वही AI का चेहरा बनेगा (मुख्य स्क्रीन और तैरते डॉट, दोनों में)।"))
        for (name in FaceConfig.list(a)) {
            val cfg = FaceConfig.load(a, name)
            val card = ui.card()
            val sel = name == current
            card.background = Theme.rounded(Theme.panel, ui.dp(16).toFloat(), if (sel) Theme.accent else Theme.line, if (sel) ui.dp(2) else ui.dp(1))
            card.addView(FaceView(a).apply { setFace(name) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(150)))
            card.addView(ui.text(cfg.title + if (sel) "   ✓ चुना हुआ" else "", 15f, if (sel) Theme.accent else Theme.text, true))
            card.setOnClickListener {
                prefs.put("face", name)
                AssistantService.instance?.reload()
                (a as com.myai.assistant.SectionActivity).rebuild()
            }
            col.addView(card)
        }
    }
}
