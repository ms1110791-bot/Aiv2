package com.myai.assistant.core

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognitionService
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** आपकी बोली हुई बात को टेक्स्ट बनाता है (Android की speech recognition; ऑफलाइन हिंदी पैक हो तो ऑफलाइन भी)। */
class Stt(private val ctx: Context, private val prefs: Prefs) {
    private var rec: SpeechRecognizer? = null
    private var gen = 0

    private fun create(): SpeechRecognizer {
        try {
            // हमारी अपनी (खाली) RecognitionService को छोड़कर Google की सर्विस चुनो
            val list = ctx.packageManager.queryIntentServices(Intent(RecognitionService.SERVICE_INTERFACE), 0)
            val pick = list.firstOrNull { it.serviceInfo.packageName == "com.google.android.googlequicksearchbox" }
                ?: list.firstOrNull { it.serviceInfo.packageName != ctx.packageName }
            if (pick != null) {
                return SpeechRecognizer.createSpeechRecognizer(
                    ctx, ComponentName(pick.serviceInfo.packageName, pick.serviceInfo.name)
                )
            }
        } catch (_: Exception) {
        }
        return SpeechRecognizer.createSpeechRecognizer(ctx)
    }

    fun listen(onResult: (String) -> Unit, onFail: () -> Unit) {
        cancel()
        val my = ++gen
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onFail()
            return
        }
        val r = create()
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onResults(results: Bundle?) {
                if (my != gen) return
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                finish(r)
                onResult(t)
            }

            override fun onError(error: Int) {
                if (my != gen) return
                finish(r)
                onFail()
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, prefs.get("lang"))
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, !isOnline(ctx))
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        }
        try {
            r.startListening(i)
        } catch (e: Exception) {
            finish(r)
            onFail()
        }
    }

    private fun finish(r: SpeechRecognizer) {
        try { r.destroy() } catch (_: Exception) {}
        if (rec === r) rec = null
    }

    fun cancel() {
        gen++
        try { rec?.cancel() } catch (_: Exception) {}
        try { rec?.destroy() } catch (_: Exception) {}
        rec = null
    }
}
