package com.myai.assistant.face

import android.content.Context
import android.graphics.Canvas
import android.os.SystemClock
import android.view.View
import com.myai.assistant.core.Bus
import com.myai.assistant.core.Prefs
import kotlin.math.sin

/** AI का चेहरा दिखाने वाला View। AI की स्थिति (सुन रहा / सोच रहा / बोल रहा) के हिसाब से हिलता है। */
class FaceView(ctx: Context) : View(ctx), Bus.Listener {
    private var cfg = FaceConfig.load(ctx, Prefs.of(ctx).get("face"))
    private var renderer: FaceRenderer = FaceRenderer.forType(cfg.type)
    private var fixed: String? = null
    private var state = Bus.state
    private var level = 0f
    private val t0 = SystemClock.uptimeMillis()

    /** किसी ख़ास चेहरे को दिखाना हो (preview) तो उसका नाम दो। */
    fun setFace(name: String) {
        fixed = name
        loadFace(name)
    }

    private fun loadFace(name: String) {
        cfg = FaceConfig.load(context, name)
        renderer = FaceRenderer.forType(cfg.type)
        invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        Bus.add(this)
        state = Bus.state
        loadFace(fixed ?: Prefs.of(context).get("face"))
    }

    override fun onDetachedFromWindow() {
        Bus.remove(this)
        super.onDetachedFromWindow()
    }

    override fun onState(s: Bus.State) {
        state = s
    }

    override fun onDraw(canvas: Canvas) {
        val t = (SystemClock.uptimeMillis() - t0) / 1000f
        val target = when (state) {
            Bus.State.SPEAKING -> 0.5f + 0.5f * sin(t * 11f) * sin(t * 6.3f)
            Bus.State.LISTENING -> 0.55f + 0.25f * sin(t * 4f)
            Bus.State.THINKING -> 0.35f
            Bus.State.IDLE -> 0.08f + 0.05f * sin(t * 1.5f)
        }
        level += (target - level) * 0.2f
        renderer.draw(canvas, width.toFloat(), height.toFloat(), t, state, level.coerceIn(0f, 1f), cfg)
        // खाली बैठे समय कम frame (बैटरी बचाने को)
        if (state == Bus.State.IDLE) postInvalidateDelayed(50) else postInvalidateOnAnimation()
    }
}
