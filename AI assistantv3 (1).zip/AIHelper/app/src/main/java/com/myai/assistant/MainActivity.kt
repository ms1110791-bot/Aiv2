package com.myai.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import com.myai.assistant.core.AppState
import com.myai.assistant.core.Bus
import com.myai.assistant.core.Prefs
import com.myai.assistant.face.FaceView
import com.myai.assistant.theme.Theme
import com.myai.assistant.ui.ChatView
import com.myai.assistant.ui.UiKit

/** मुख्य स्क्रीन: चेहरा + चैट + 🎤। सारी settings ऊपर दाएँ ⋮ (तीन डॉट) मेन्यू में हैं। */
class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var ui: UiKit
    private lateinit var title: TextView
    private lateinit var chip: TextView
    private lateinit var status: TextView
    private lateinit var input: EditText
    private val main = Handler(Looper.getMainLooper())

    private val listener = object : Bus.Listener {
        override fun onState(s: Bus.State) {
            refreshStatus()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Theme.load(this)
        prefs = Prefs.of(this)
        ui = UiKit(this)
        window.statusBarColor = Theme.bg
        window.navigationBarColor = Theme.bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Theme.backdrop()
            fitsSystemWindows = true
        }

        // ऊपर की पट्टी: नाम | चालू/बंद | ⋮
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ui.dp(18), ui.dp(10), ui.dp(6), ui.dp(2))
        }
        title = ui.text("", 20f, Theme.accent, true).apply { letterSpacing = 0.28f }
        chip = ui.text("", 12f, Theme.ok, true).apply {
            setPadding(ui.dp(12), ui.dp(6), ui.dp(12), ui.dp(6))
            background = Theme.rounded(Theme.panelAlt, ui.dp(14).toFloat(), Theme.line, 1)
            setOnClickListener { toggleService() }
        }
        val menu = ui.text("⋮", 28f, Theme.text).apply {
            setPadding(ui.dp(14), ui.dp(0), ui.dp(12), ui.dp(2))
            setOnClickListener { showMenu(it) }
        }
        bar.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(chip)
        bar.addView(menu)
        root.addView(bar)

        // चेहरा
        root.addView(FaceView(this), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ui.dp(230)))

        status = ui.text("", 12f, Theme.textDim).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.08f
        }
        root.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // चैट
        root.addView(
            ChatView(this),
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply {
                setMargins(ui.dp(14), ui.dp(8), ui.dp(14), ui.dp(4))
            }
        )

        // नीचे: लिखो + 🎤 + ➤
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ui.dp(12), ui.dp(6), ui.dp(12), ui.dp(12))
        }
        input = EditText(this).apply {
            hint = "यहाँ लिखो…"
            setHintTextColor(Theme.textDim)
            setTextColor(Theme.text)
            textSize = 15f
            maxLines = 3
            imeOptions = EditorInfo.IME_ACTION_SEND
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            setPadding(ui.dp(16), ui.dp(10), ui.dp(16), ui.dp(10))
            background = Theme.rounded(Theme.panelAlt, ui.dp(24).toFloat(), Theme.line, 1)
            setOnEditorActionListener { _, id, ev ->
                if (id == EditorInfo.IME_ACTION_SEND || ev?.keyCode == KeyEvent.KEYCODE_ENTER) { send(); true } else false
            }
        }
        fun round(label: String, fill: Int, onClick: () -> Unit) = TextView(this).apply {
            text = label
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Theme.bg)
            background = Theme.rounded(fill, ui.dp(26).toFloat())
            setOnClickListener { onClick() }
        }
        row.addView(input, LinearLayout.LayoutParams(0, ui.dp(52), 1f))
        row.addView(round("🎤", Theme.accent) { mic() }, LinearLayout.LayoutParams(ui.dp(52), ui.dp(52)).apply { marginStart = ui.dp(8) })
        row.addView(round("➤", Theme.ok) { send() }, LinearLayout.LayoutParams(ui.dp(52), ui.dp(52)).apply { marginStart = ui.dp(8) })
        root.addView(row)

        setContentView(root)

        if (!hasMic()) {
            requestPermissions(perms(), 1)
        } else if (prefs.bool("enabled")) {
            AssistantService.start(this)
        }
    }

    override fun onStart() {
        super.onStart()
        AppState.appVisible = true
        Bus.add(listener)
        title.text = prefs.get("name").uppercase()
        AssistantService.instance?.onAppVisibility()
        refreshStatus()
        main.postDelayed({ refreshStatus() }, 700)
    }

    override fun onStop() {
        AppState.appVisible = false
        Bus.remove(listener)
        AssistantService.instance?.onAppVisibility()
        super.onStop()
    }

    private fun perms(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        else arrayOf(Manifest.permission.RECORD_AUDIO)

    private fun hasMic() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (hasMic()) {
            prefs.putBool("enabled", true)
            AssistantService.start(this)
            main.postDelayed({ refreshStatus() }, 700)
        } else {
            Toast.makeText(this, "Mic permission ज़रूरी है", Toast.LENGTH_LONG).show()
        }
    }

    private fun refreshStatus() {
        val on = AppState.serviceOn
        chip.text = if (on) "● चालू" else "○ बंद"
        chip.setTextColor(if (on) Theme.ok else Theme.danger)
        status.text = when {
            !on -> "बंद है। ऊपर 'बंद' दबाकर चालू करो"
            Bus.state == Bus.State.LISTENING -> "सुन रहा हूँ…"
            Bus.state == Bus.State.THINKING -> "सोच रहा हूँ…"
            Bus.state == Bus.State.SPEAKING -> "बोल रहा हूँ…"
            else -> "‘${prefs.get("name")}’ बोलो, या 🎤 दबाओ"
        }
    }

    private fun toggleService() {
        if (AppState.serviceOn) {
            prefs.putBool("enabled", false)
            AssistantService.stop(this)
        } else {
            if (!hasMic()) {
                requestPermissions(perms(), 1)
                return
            }
            prefs.putBool("enabled", true)
            AssistantService.start(this)
        }
        main.postDelayed({ refreshStatus() }, 600)
    }

    /** सर्विस चालू न हो तो पहले चालू करो, फिर काम भेजो। */
    private fun withService(block: (AssistantService) -> Unit) {
        val s = AssistantService.instance
        if (s != null) {
            block(s)
            return
        }
        if (!hasMic()) {
            requestPermissions(perms(), 1)
            return
        }
        prefs.putBool("enabled", true)
        AssistantService.start(this)
        main.postDelayed({ AssistantService.instance?.let(block) }, 800)
    }

    private fun mic() {
        withService { it.micTap() }
    }

    private fun send() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0)
        withService { it.submit(t) }
    }

    private fun showMenu(anchor: android.view.View) {
        val m = PopupMenu(this, anchor)
        val items = listOf(
            "ai" to "AI APIs",
            "voice" to "आवाज़ (Voice) API",
            "search" to "सर्च API",
            "wake" to "नाम / Wake word",
            "voiceid" to "मेरी आवाज़ पहचान",
            "face" to "AI का चेहरा",
            "perms" to "Permissions / असिस्टेंट बनाओ"
        )
        items.forEachIndexed { i, p -> m.menu.add(0, i, i, p.second) }
        m.menu.add(0, 100, 100, "चैट साफ़ करो")
        m.setOnMenuItemClickListener { mi ->
            if (mi.itemId == 100) {
                Bus.clear()
            } else {
                startActivity(Intent(this, SectionActivity::class.java).putExtra("s", items[mi.itemId].first))
            }
            true
        }
        m.show()
    }
}
