package com.myai.assistant.providers

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.myai.assistant.core.Http
import com.myai.assistant.core.Prefs
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.util.Locale
import kotlin.coroutines.resume

interface VoiceProvider {
    suspend fun speak(text: String)
    fun stop()
}

/** ElevenLabs की आवाज़ (ऑनलाइन)। */
class ElevenVoice(private val ctx: Context, private val p: Prefs) : VoiceProvider {
    private var mp: MediaPlayer? = null

    override suspend fun speak(text: String) {
        val f = File(ctx.cacheDir, "tts.mp3")
        withContext(Dispatchers.IO) {
            val body = JSONObject().put("text", text).put("model_id", p.get("elevenModel")).toString()
            val bytes = Http.request(
                "https://api.elevenlabs.io/v1/text-to-speech/" + p.get("elevenVoice") + "?output_format=mp3_44100_64",
                "POST", body,
                mapOf("xi-api-key" to p.get("elevenKey"), "Content-Type" to "application/json")
            )
            f.writeBytes(bytes)
        }
        suspendCancellableCoroutine<Unit> { cont ->
            val m = MediaPlayer()
            mp = m
            m.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            m.setDataSource(f.absolutePath)
            m.setOnCompletionListener {
                m.release(); mp = null
                if (cont.isActive) cont.resume(Unit)
            }
            m.setOnErrorListener { _, _, _ ->
                m.release(); mp = null
                if (cont.isActive) cont.resume(Unit)
                true
            }
            m.setOnPreparedListener { it.start() }
            m.prepareAsync()
            cont.invokeOnCancellation { try { m.release() } catch (_: Exception) {} }
        }
    }

    override fun stop() {
        try { mp?.stop(); mp?.release() } catch (_: Exception) {}
        mp = null
    }
}

/** फ़ोन की अपनी आवाज़ (ऑफलाइन चलती है, कोई key नहीं चाहिए)। */
class AndroidVoice(ctx: Context, private val p: Prefs) : VoiceProvider {
    private var ready = false
    private var pending: (() -> Unit)? = null
    private lateinit var tts: TextToSpeech

    init {
        tts = TextToSpeech(ctx.applicationContext) { st ->
            ready = st == TextToSpeech.SUCCESS
            if (ready) {
                pending?.invoke()
                pending = null
            }
        }
    }

    override suspend fun speak(text: String) = suspendCancellableCoroutine<Unit> { cont ->
        fun run() {
            tts.setLanguage(Locale.forLanguageTag(p.get("lang")))
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { if (cont.isActive) cont.resume(Unit) }
                override fun onError(utteranceId: String?) { if (cont.isActive) cont.resume(Unit) }
            })
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, System.nanoTime().toString())
        }
        if (ready) run() else pending = { run() }
        cont.invokeOnCancellation { tts.stop() }
    }

    override fun stop() {
        try { tts.stop() } catch (_: Exception) {}
    }
}

/** ElevenLabs key हो और ऑनलाइन हो तो ElevenLabs, वरना फ़ोन की आवाज़। */
class VoiceRouter(ctx: Context, private val p: Prefs) {
    private val eleven = ElevenVoice(ctx, p)
    private val local = AndroidVoice(ctx, p)

    suspend fun speak(text: String, premium: Boolean, online: Boolean) {
        if (text.isBlank()) return
        if (premium && online && p.bool("useEleven") && p.get("elevenKey").isNotBlank()) {
            try {
                eleven.speak(text)
                return
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // ElevenLabs फेल हुआ → फ़ोन की आवाज़ से बोलो
            }
        }
        local.speak(text)
    }

    fun stop() {
        eleven.stop()
        local.stop()
    }
}
