package com.myai.assistant.ui.sections

import ai.picovoice.porcupine.Porcupine
import android.app.Activity
import android.net.Uri
import android.provider.OpenableColumns
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.Toast
import com.myai.assistant.SectionActivity
import com.myai.assistant.core.Prefs
import com.myai.assistant.theme.Theme
import com.myai.assistant.ui.UiKit
import java.io.File

/** AI का नाम और उसे सुनने का तरीका (Porcupine, माइक लगातार ON)। */
object WakeSection {
    fun build(a: SectionActivity, col: LinearLayout) {
        val ui = UiKit(a)
        val prefs = Prefs.of(a)

        col.addView(ui.hint("नाम बोलते ही AI जागेगा। Picovoice key भरो तो माइक लगातार ON रहता है (बार-बार ON/OFF नहीं)। key न हो तो फ़ोन की speech से काम चलता है, पर तब माइक बार-बार चालू-बंद होगा।"))

        val c1 = ui.card()
        ui.field(c1, "AI का नाम (स्क्रीन पर दिखेगा)", "name")
        ui.field(c1, "बैकअप: नाम बोलने के तरीके (कॉमा से)", "wake")
        col.addView(c1)

        val c2 = ui.card()
        c2.addView(ui.text("Picovoice Porcupine", 15f, Theme.accent, true))
        ui.field(c2, "Picovoice AccessKey (console.picovoice.ai)", "picoKey", secret = true)

        c2.addView(ui.text("बना-बनाया नाम (अपना .ppn न हो तब)", 12f, Theme.textDim).apply { setPadding(0, ui.dp(12), 0, ui.dp(4)) })
        val names = try { Porcupine.BuiltInKeyword.values().map { it.name } } catch (e: Throwable) { listOf("JARVIS") }
        val sp = Spinner(a)
        sp.adapter = ArrayAdapter(a, android.R.layout.simple_spinner_dropdown_item, names)
        sp.setSelection(names.indexOf(prefs.get("picoKeyword")).coerceAtLeast(0), false)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.put("picoKeyword", names[pos])
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        c2.addView(sp)

        fun fileRow(label: String, key: String, folder: String) {
            val cur = prefs.get(key)
            c2.addView(ui.text(
                label + ": " + (if (cur.isBlank()) "चुना नहीं" else File(cur).name), 13f,
                if (cur.isBlank()) Theme.textDim else Theme.ok
            ).apply { setPadding(0, ui.dp(12), 0, 0) })
            c2.addView(ui.button("📂 $label चुनो") {
                a.pick { uri ->
                    if (uri != null) {
                        val path = copy(a, uri, folder)
                        if (path != null) prefs.put(key, path) else Toast.makeText(a, "फ़ाइल नहीं चुनी जा सकी", Toast.LENGTH_SHORT).show()
                    }
                }
            })
            if (cur.isNotBlank()) c2.addView(ui.button("हटाओ") { File(cur).delete(); prefs.put(key, ""); a.rebuild() })
        }
        fileRow("अपना नाम (.ppn)", "picoPpn", "wake")
        fileRow("भाषा मॉडल (.pv, ज़रूरत हो तो)", "picoModel", "wake")
        col.addView(c2)

        col.addView(ui.hint("अपना नाम बनाना: console.picovoice.ai → Porcupine → नाम लिखो → Platform: Android → Train → .ppn डाउनलोड करके ऊपर से चुनो। उपलब्ध भाषाएँ और शर्तें उनकी साइट पर देखो।"))
    }

    private fun copy(a: Activity, uri: Uri, folder: String): String? = try {
        var name = "file"
        a.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) name = c.getString(i)
        }
        val dir = File(a.filesDir, folder).apply { mkdirs() }
        val out = File(dir, name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
        a.contentResolver.openInputStream(uri)!!.use { input -> out.outputStream().use { input.copyTo(it) } }
        out.absolutePath
    } catch (e: Exception) {
        null
    }
}
