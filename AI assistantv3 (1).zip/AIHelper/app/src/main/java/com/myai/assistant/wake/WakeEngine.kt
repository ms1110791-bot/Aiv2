package com.myai.assistant.wake

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.myai.assistant.core.Prefs
import com.myai.assistant.core.Stt

/** नाम सुनने वाला इंजन। नया इंजन चाहिए तो यह interface implement करके AssistantService.startWake() में जोड़ दो। */
interface WakeEngine {
    fun start()
    fun stop()
}

/**
 * बैकअप: Picovoice key न हो तो फ़ोन की speech recognition बार-बार सुनकर नाम पकड़ता है।
 * (इसमें माइक बार-बार ON/OFF होता है और बीप आ सकती है। लगातार सुनने के लिए Picovoice key डालो।)
 */
class SpeechWake(ctx: Context, private val prefs: Prefs, private val onWake: () -> Unit) : WakeEngine {
    private val stt = Stt(ctx, prefs)
    private val main = Handler(Looper.getMainLooper())
    private var run = false

    override fun start() {
        if (run) return
        run = true
        next()
    }

    private fun hit(t: String): Boolean {
        val l = t.lowercase()
        val names = (prefs.get("wake") + "," + prefs.get("name")).split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        return names.any { l.contains(it) }
    }

    private fun next() {
        if (!run) return
        stt.listen({ t ->
            if (run) {
                if (hit(t)) {
                    run = false
                    onWake()
                } else {
                    main.postDelayed({ next() }, 150)
                }
            }
        }, {
            if (run) main.postDelayed({ next() }, 400)
        })
    }

    override fun stop() {
        run = false
        stt.cancel()
        main.removeCallbacksAndMessages(null)
    }
}
