package com.myai.assistant.providers

import com.myai.assistant.core.Http
import com.myai.assistant.core.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URLEncoder

interface SearchProvider {
    suspend fun search(q: String): String?
}

/** Google Custom Search API (optional)। key + cx डालने पर चालू होता है। नया सर्च इंजन चाहिए तो यहाँ दूसरी क्लास जोड़ो। */
class GoogleSearch(private val p: Prefs) : SearchProvider {
    override suspend fun search(q: String): String? = withContext(Dispatchers.IO) {
        val key = p.get("searchKey")
        val cx = p.get("searchCx")
        if (key.isBlank() || cx.isBlank()) return@withContext null
        val url = "https://www.googleapis.com/customsearch/v1?key=" + enc(key) +
                "&cx=" + enc(cx) + "&num=5&q=" + enc(q)
        val items = JSONObject(String(Http.request(url))).optJSONArray("items") ?: return@withContext null
        buildString {
            for (i in 0 until items.length()) {
                val o = items.getJSONObject(i)
                append("- ").append(o.optString("title")).append(": ")
                    .append(o.optString("snippet")).append(" (").append(o.optString("link")).append(")\n")
            }
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
}
