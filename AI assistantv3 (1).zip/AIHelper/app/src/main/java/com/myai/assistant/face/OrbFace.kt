package com.myai.assistant.face

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import androidx.core.graphics.ColorUtils
import com.myai.assistant.core.Bus
import kotlin.math.sin

/** Jarvis जैसा चमकता 3D गोला: ग्रेडिएंट + घूमते छल्ले। बोलते समय धड़कता है, सोचते समय तेज़ घूमता है। */
class OrbFace : FaceRenderer {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val oval = RectF()

    override fun draw(c: Canvas, w: Float, h: Float, t: Float, state: Bus.State, level: Float, cfg: FaceConfig) {
        val cx = w / 2f
        val cy = h / 2f
        val r = minOf(w, h) * 0.30f * (1f + 0.07f * level)
        val sp = cfg.speed * if (state == Bus.State.THINKING) 2.6f else 1f

        // बाहर की चमक
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(
            cx, cy, r * 2.1f,
            intArrayOf(alpha(cfg.glow, 110 + (70 * level).toInt()), alpha(cfg.glow, 0)),
            null, Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, r * 2.1f, p)

        // गोला (ऊपर-बाएँ से रोशनी, ताकि 3D दिखे)
        p.shader = RadialGradient(
            cx - r * 0.35f, cy - r * 0.40f, r * 1.35f,
            intArrayOf(
                ColorUtils.blendARGB(cfg.glow, Color.WHITE, 0.5f), cfg.primary, cfg.secondary,
                ColorUtils.blendARGB(cfg.secondary, Color.BLACK, 0.75f)
            ),
            floatArrayOf(0f, 0.3f, 0.7f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, r, p)
        p.shader = null

        // घूमते छल्ले
        p.style = Paint.Style.STROKE
        p.strokeWidth = maxOf(2f, r * 0.04f)
        for (i in 0..2) {
            c.save()
            c.rotate(t * sp * (24f + 14f * i) + i * 58f, cx, cy)
            val rx = r * (1.28f + 0.06f * i)
            val ry = r * (0.32f + 0.16f * i + 0.04f * sin(t * sp * 2f + i))
            oval.set(cx - rx, cy - ry, cx + rx, cy + ry)
            p.color = alpha(cfg.glow, 220 - 55 * i)
            c.drawOval(oval, p)
            c.restore()
        }

        // बीच की चमकती आँख
        p.style = Paint.Style.FILL
        p.color = alpha(Color.WHITE, 190 + (60 * level).toInt())
        c.drawCircle(cx, cy, r * 0.14f * (1f + 0.5f * level), p)
    }
}
