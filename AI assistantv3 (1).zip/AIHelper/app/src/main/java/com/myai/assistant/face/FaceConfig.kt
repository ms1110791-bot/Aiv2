package com.myai.assistant.face

import android.content.Context
import android.graphics.Color
import org.json.JSONObject

/** assets/faces/<नाम>.json से चेहरे का रंग/speed पढ़ता है। */
data class FaceConfig(
    val name: String,
    val title: String,
    val type: String,
    val primary: Int,
    val secondary: Int,
    val glow: Int,
    val speed: Float
) {
    companion object {
        fun list(ctx: Context): List<String> = try {
            ctx.assets.list("faces")?.filter { it.endsWith(".json") }?.map { it.removeSuffix(".json") }?.sorted()
                ?: listOf("orb")
        } catch (e: Exception) {
            listOf("orb")
        }

        fun load(ctx: Context, name: String): FaceConfig {
            return try {
                val j = JSONObject(ctx.assets.open("faces/$name.json").bufferedReader().use { it.readText() })
                fun c(k: String, d: Int) = try { Color.parseColor(j.getString(k)) } catch (e: Exception) { d }
                FaceConfig(
                    name, j.optString("title", name), j.optString("type", "orb"),
                    c("primary", 0xFF00E5FF.toInt()), c("secondary", 0xFF1565C0.toInt()), c("glow", 0xFF7DF3FF.toInt()),
                    j.optDouble("speed", 1.0).toFloat()
                )
            } catch (e: Exception) {
                FaceConfig("orb", "Arc Orb", "orb", 0xFF00E5FF.toInt(), 0xFF1565C0.toInt(), 0xFF7DF3FF.toInt(), 1f)
            }
        }
    }
}
