package com.myai.assistant.ui.sections

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.widget.LinearLayout
import com.myai.assistant.ControlService
import com.myai.assistant.core.Prefs
import com.myai.assistant.theme.Theme
import com.myai.assistant.ui.UiKit

/** सारी permissions एक जगह, हर एक के आगे ✓ / ✗ के साथ। */
object PermsSection {
    fun build(a: Activity, col: LinearLayout) {
        val ui = UiKit(a)
        val prefs = Prefs.of(a)
        col.addView(ui.hint("हर चीज़ एक बार देनी है। ✓ मतलब मिल चुकी है।"))

        fun row(label: String, ok: Boolean?, action: () -> Unit) {
            val mark = when (ok) { true -> "✓ "; false -> "✗ "; null -> "• " }
            col.addView(ui.button(mark + label) { action() })
        }

        row("माइक (सुनने के लिए)", a.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            a.requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 3)
        }
        row(
            "नोटिफिकेशन",
            if (Build.VERSION.SDK_INT >= 33) a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED else true
        ) {
            if (Build.VERSION.SDK_INT >= 33) a.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 4)
        }
        row("Overlay (तैरता डॉट / विंडो)", Settings.canDrawOverlays(a)) {
            a.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${a.packageName}")))
        }
        row("Accessibility (फ़ोन कंट्रोल: टैप/स्क्रॉल)", ControlService.instance != null) {
            a.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        row("Write settings (ब्राइटनेस)", Settings.System.canWrite(a)) {
            a.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${a.packageName}")))
        }
        val pm = a.getSystemService(Context.POWER_SERVICE) as PowerManager
        row("Battery: Unrestricted (बैकग्राउंड में चलता रहे)", pm.isIgnoringBatteryOptimizations(a.packageName)) {
            a.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }

        col.addView(ui.text("\nतैरता डॉट", 14f, Theme.text, true))
        ui.switchRow(col, "ऐप बंद होने पर छोटा डॉट दिखाओ", "dot") {
            com.myai.assistant.AssistantService.instance?.reload()
        }

        col.addView(ui.text("\nAI को बुलाने के और तरीके", 14f, Theme.text, true))
        col.addView(ui.hint("1) नाम बोलो  2) नोटिफिकेशन में 'बुलाओ'  3) तैरते डॉट पर टैप  4) मुख्य स्क्रीन पर 🎤  5) Quick Settings में 'AI Helper' टाइल जोड़ो (नोटिफिकेशन पैनल → पेंसिल/Edit)  6) नीचे वाला: डिफ़ॉल्ट असिस्टेंट"))
        col.addView(ui.button("⭐ डिफ़ॉल्ट असिस्टेंट चुनो (पावर बटन / होम जेस्चर)") {
            try {
                a.startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
            } catch (e: Exception) {
                a.startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        })
    }
}
