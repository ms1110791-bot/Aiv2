package com.myai.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import android.speech.SpeechRecognizer

/*
 * "डिफ़ॉल्ट डिजिटल असिस्टेंट" बनने के लिए ज़रूरी हिस्से।
 * Settings → Apps → Default apps → Digital assistant app में इस ऐप को चुनो;
 * फिर पावर बटन लंबा दबाने / होम जेस्चर पर AI खुलेगा।
 */
class AssistVoiceService : VoiceInteractionService()

class AssistSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = AssistSession(this)
}

class AssistSession(ctx: Context) : VoiceInteractionSession(ctx) {
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        AssistantService.summon(context)
        hide()
    }
}

/** सिस्टम इसे माँगता है; असली बोली-पहचान हम Google की सर्विस से करते हैं, इसलिए यह खाली है। */
class AssistRecognitionService : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        try { listener?.error(SpeechRecognizer.ERROR_CLIENT) } catch (_: Exception) {}
    }

    override fun onCancel(listener: Callback?) {}
    override fun onStopListening(listener: Callback?) {}
}
