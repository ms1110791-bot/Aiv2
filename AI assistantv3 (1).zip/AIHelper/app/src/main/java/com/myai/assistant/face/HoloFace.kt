package com.myai.assistant.face

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import androidx.core.graphics.ColorUtils
import com.myai.assistant.core.Bus
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** असली 3D: गोले पर बिखरे बिंदु घूमते हैं (perspective के साथ), आगे की तरफ़ दो चमकती आँखें। */
class HoloFace : FaceRenderer {
    private val n = 240
    private val px = FloatArray(n)
    private val py = FloatArray(n)
    private val pz = FloatArray(n)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val oval = RectF()

    init {
        val ga = Math.PI * (3.0 - sqrt(5.0))
        for (i in 0 until n) {
            val y = 1f - 2f * (i + 0.5f) / n
            val rad = sqrt(1f - y * y)
            val th = ga * i
            px[i] = (cos(th) * rad).toFloat()
            py[i] = y
            pz[i] = (sin(th) * rad).toFloat()
        }
    }

    override fun draw(c: Canvas, w: Float, h: Float, t: Float, state: Bus.State, level: Float, cfg: FaceConfig) {
        val cx = w / 2f
        val cy = h / 2f
        val r = minOf(w, h) * 0.31f * (1f + 0.06f * level)
        val spin = t * cfg.speed * if (state == Bus.State.THINKING) 2.8f else 0.7f
        val tilt = 0.38f
        val ca = cos(spin); val sa = sin(spin)
        val ct = cos(tilt); val st = sin(tilt)

        p.style = Paint.Style.FILL
        p.shader = RadialGradient(
            cx, cy, r * 1.9f,
            intArrayOf(alpha(cfg.glow, 60 + (60 * level).toInt()), alpha(cfg.glow, 0)),
            null, Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, r * 1.9f, p)
        p.shader = null

        // बिंदु: पीछे वाले धुंधले, आगे वाले चमकदार
        for (i in 0 until n) {
            val x1 = px[i] * ca + pz[i] * sa
            val z1 = -px[i] * sa + pz[i] * ca
            val y2 = py[i] * ct - z1 * st
            val z2 = py[i] * st + z1 * ct
            val depth = (z2 + 1f) / 2f
            p.color = alpha(ColorUtils.blendARGB(cfg.secondary, cfg.glow, depth), 50 + (200 * depth).toInt())
            c.drawCircle(cx + x1 * r, cy + y2 * r, r * (0.010f + 0.022f * depth), p)
        }

        // भूमध्य रेखा के छल्ले
        p.style = Paint.Style.STROKE
        p.strokeWidth = maxOf(1.5f, r * 0.025f)
        for (i in 0..1) {
            c.save()
            c.rotate(-spin * 20f * (i + 1) + i * 70f, cx, cy)
            val rx = r * (1.22f + 0.1f * i)
            val ry = r * (0.22f + 0.1f * i)
            oval.set(cx - rx, cy - ry, cx + rx, cy + ry)
            p.color = alpha(cfg.primary, 190 - 50 * i)
            c.drawOval(oval, p)
            c.restore()
        }

        // आँखें (स्थिर, हमेशा सामने)
        val ph = (t * cfg.speed) % 4.6f
        val blink = if (ph > 4.45f) 0.15f else 1f
        p.style = Paint.Style.FILL
        for (sx in intArrayOf(-1, 1)) {
            val ex = cx + sx * r * 0.34f
            val ey = cy - r * 0.10f
            p.color = alpha(Color.WHITE, 235)
            oval.set(ex - r * 0.09f, ey - r * 0.07f * blink * (1f + 0.4f * level), ex + r * 0.09f, ey + r * 0.07f * blink * (1f + 0.4f * level))
            c.drawOval(oval, p)
        }
    }
}
