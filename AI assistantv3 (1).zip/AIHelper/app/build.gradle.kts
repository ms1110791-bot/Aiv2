plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.myai.assistant"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.myai.assistant"
        minSdk = 28
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // नाम सुनना (wake word) और आवाज़ पहचान: Picovoice (एक ही AccessKey दोनों के लिए)
    implementation("ai.picovoice:porcupine-android:+")
    implementation("ai.picovoice:eagle-android:+")
}
