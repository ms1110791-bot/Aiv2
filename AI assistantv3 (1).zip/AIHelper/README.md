# AI Helper v2 (Android, Kotlin)

AI का नाम बोलो → AI जागता है → तैरती विंडो में चैट + आवाज़।

## फ़ोल्डर ढाँचा (हर चीज़ अलग फ़ाइल)
```
app/src/main/
  assets/
    styles/jarvis.json     ← सारे रंग/थीम यहाँ बदलो
    faces/*.json           ← चेहरे (रंग, speed); नई .json डालो = नया चेहरा
    wake/README.txt        ← अपना wake-word बनाने की विधि
  java/com/myai/assistant/
    face/        OrbFace.kt, RobotFace.kt, HoloFace.kt, FaceView.kt   ← 3D चेहरे (अलग-अलग फ़ाइल)
    theme/       Theme.kt
    providers/   Llm.kt (कई AI), Search.kt, Voice.kt (ElevenLabs / फ़ोन की आवाज़)
    wake/        PicoWake.kt (नाम सुनना), VoiceId.kt (आपकी आवाज़), WakeEngine.kt
    core/        Brain.kt, Actions.kt (फ़ोन कमांड), Stt.kt, Prefs.kt, Bus.kt, Http.kt
    ui/          FloatingWindow.kt (डॉट + पैनल), ChatView.kt, UiKit.kt
    ui/sections/ AiSection, VoiceSection, SearchSection, WakeSection, VoiceIdSection, FaceSection, PermsSection
    MainActivity.kt, SectionActivity.kt, AssistantService.kt, ControlService.kt, AssistTile.kt, VoiceAssist.kt
```

## बाद में अपग्रेड (पूरा कोड बदले बिना)
- नया AI/API: ऐप में ⋮ → AI APIs → जोड़ो (कोड नहीं)।
- नया चेहरा/रंग: `assets/faces/` या `assets/styles/` की json बदलो।
- नया ऑफलाइन कमांड: `core/Actions.kt` → `OfflineMatcher` में एक लाइन।
- नया फ़ोन-काम: `DeviceController.exec()` में एक branch।
- नया settings हिस्सा: `ui/sections/` में नई फ़ाइल + `SectionActivity` में एक लाइन।

## पहली बार
1. ऐप खोलो → Mic permission दो। (बिना किसी API के भी फ़ोन-कमांड, ब्राउज़र सर्च और फ़ोन की आवाज़ चलती है।)
2. ⋮ → Permissions: Overlay, Accessibility, Write settings, Battery।
3. ⋮ → नाम / Wake word: Picovoice AccessKey डालो (माइक लगातार ON रखने के लिए)।
4. ⋮ → AI APIs: Gemini key डालो (सिर्फ़ AIza… वाली key)।
