package com.myai.assistant.ui.sections

import android.Manifest
import android.content.pm.PackageManager
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Toast
import com.myai.assistant.AssistantService
import com.myai.assistant.SectionActivity
import com.myai.assistant.core.Prefs
import com.myai.assistant.theme.Theme
import com.myai.assistant.ui.UiKit
import com.myai.assistant.wake.VoiceId

/** आपकी आवाज़ पहचानना (Picovoice Eagle): सिर्फ़ आपके बोलने पर AI जागे। उसी Picovoice key से चलता है। */
object VoiceIdSection {
    fun build(a: SectionActivity, col: LinearLayout) {
        val ui = UiKit(a)
        val prefs = Prefs.of(a)
        val vid = VoiceId(a, prefs)

        col.addView(ui.hint("Gemini की तरह आपकी आवाज़ पहचानने का फ़ीचर। इसके लिए नाम/Wake word वाले हिस्से में Picovoice key भरी होनी चाहिए। सब ऑन-डिवाइस होता है।"))

        val c1 = ui.card()
        c1.addView(ui.text(
            if (vid.hasProfile()) "✓ आवाज़ रजिस्टर है" else "आवाज़ अभी रजिस्टर नहीं है", 15f,
            if (vid.hasProfile()) Theme.ok else Theme.textDim, true
        ))
        val progress = ui.hint("")
        c1.addView(progress)
        c1.addView(ui.button("🎙 आवाज़ रजिस्टर करो") {
            when {
                prefs.picoKey.isBlank() -> Toast.makeText(a, "पहले Picovoice AccessKey डालो", Toast.LENGTH_LONG).show()
                a.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED ->
                    a.requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 5)
                else -> {
                    AssistantService.instance?.pauseWake()
                    progress.text = "शांत जगह में बोलते रहो (कुछ भी, 20-30 सेकंड)… 0%"
                    vid.enroll(
                        onProgress = { progress.text = "बोलते रहो… $it%" },
                        onDone = { ok, msg ->
                            Toast.makeText(a, msg, Toast.LENGTH_LONG).show()
                            AssistantService.instance?.reload()
                            if (!a.isDestroyed) a.rebuild()
                        }
                    )
                }
            }
        })
        if (vid.hasProfile()) c1.addView(ui.button("🗑 रजिस्टर की आवाज़ हटाओ") {
            vid.deleteProfile()
            prefs.putBool("voiceIdOn", false)
            AssistantService.instance?.reload()
            a.rebuild()
        })
        col.addView(c1)

        val c2 = ui.card()
        ui.switchRow(c2, "सिर्फ़ मेरी आवाज़ पर जागो", "voiceIdOn")
        c2.addView(ui.text("सख़्ती (ऊँची = दूसरों को ज़्यादा रोकेगी, पर आपको भी कभी-कभी)", 12f, Theme.textDim).apply { setPadding(0, ui.dp(10), 0, ui.dp(4)) })
        val label = ui.text("", 13f, Theme.accent)
        val bar = SeekBar(a).apply {
            max = 70
            progress = (prefs.threshold * 100).toInt().coerceIn(20, 90) - 20
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = (p + 20) / 100f
                    label.text = "%.2f".format(v)
                    if (fromUser) prefs.put("voiceIdTh", v.toString())
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        label.text = "%.2f".format(prefs.threshold)
        c2.addView(bar)
        c2.addView(label)
        col.addView(c2)

        col.addView(ui.hint("ध्यान रखो: यह सिर्फ़ नाम बोलने पर जागने की जाँच करता है। Picovoice key वाला (लगातार सुनने वाला) तरीका ही इसके साथ चलता है।"))
    }
}
